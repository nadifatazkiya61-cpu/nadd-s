
// ===== Utilities
const $ = (q, ctx=document)=>ctx.querySelector(q);
const $$ = (q, ctx=document)=>Array.from(ctx.querySelectorAll(q));
const fmt = n => new Intl.NumberFormat('id-ID',{style:'currency', currency:'IDR', maximumFractionDigits:0}).format(n);

// ===== Theme
const root = document.documentElement;
const themeToggle = $("#themeToggle");
const savedTheme = localStorage.getItem("sc-theme") || "dark";
if(savedTheme === "light"){ root.classList.add("light"); }
themeToggle?.addEventListener("click", ()=>{
  root.classList.toggle("light");
  localStorage.setItem("sc-theme", root.classList.contains("light") ? "light" : "dark");
});

// ===== Year
$("#year").textContent = new Date().getFullYear();

// ===== Appear on scroll animation
const io = new IntersectionObserver((entries)=>{
  for(const e of entries){
    if(e.isIntersecting){
      const delay = +e.target.dataset.delay || 0;
      setTimeout(()=> e.target.classList.add("in"), delay);
      io.unobserve(e.target);
    }
  }
},{threshold:.2});
$$("[data-animate]").forEach(el=> io.observe(el));

// ===== Simple slider
const track = $("#sliderTrack");
let idx = 0;
const to = i => {
  idx = (i + track.children.length) % track.children.length;
  track.scrollTo({left: track.clientWidth * idx, behavior:'smooth'});
}
$("#slidePrev").addEventListener("click",()=>to(idx-1));
$("#slideNext").addEventListener("click",()=>to(idx+1));
// Touch support
let startX = 0;
track.addEventListener("touchstart",e=> startX = e.touches[0].clientX);
track.addEventListener("touchend",e=>{
  const dx = e.changedTouches[0].clientX - startX;
  if(Math.abs(dx) > 40) to(idx + (dx < 0 ? 1 : -1));
});

// ===== Products data
const PRODUCTS = [
  {id:'ck1', name:'Chocolate Fudge Cake', price:120000, cat:'cake', flavor:'chocolate', img:'https://images.unsplash.com/photo-1606313564200-e75d5e30476d?q=80&w=1200&auto=format&fit=crop', popular:true},
  {id:'ck2', name:'Strawberry Cheesecake', price:135000, cat:'cake', flavor:'strawberry', img:'https://images.unsplash.com/photo-1606313564213-474f536a42ab?q=80&w=1200&auto=format&fit=crop', popular:true},
  {id:'ps1', name:'Butter Croissant', price:22000, cat:'pastry', flavor:'vanilla', img:'https://images.unsplash.com/photo-1541782814455-11e4e5e69b41?q=80&w=1200&auto=format&fit=crop', popular:true},
  {id:'ps2', name:'Matcha Éclair', price:26000, cat:'pastry', flavor:'matcha', img:'https://images.unsplash.com/photo-1568051243851-5cd2b93fd520?q=80&w=1200&auto=format&fit=crop'},
  {id:'br1', name:'Japanese Milk Bread', price:28000, cat:'bread', flavor:'vanilla', img:'https://images.unsplash.com/photo-1540304804-5f6f45d06ca4?q=80&w=1200&auto=format&fit=crop'},
  {id:'co1', name:'Dark Choco Cookies', price:18000, cat:'cookies', flavor:'chocolate', img:'https://images.unsplash.com/photo-1549931319-3b3b57a45ed3?q=80&w=1200&auto=format&fit=crop'},
  {id:'co2', name:'Cheese Cookies', price:19000, cat:'cookies', flavor:'cheese', img:'https://images.unsplash.com/photo-1606313564161-0425df18b8b5?q=80&w=1200&auto=format&fit=crop'},
  {id:'ck3', name:'Vanilla Birthday Cake', price:110000, cat:'cake', flavor:'vanilla', img:'https://images.unsplash.com/photo-1551024709-8f23befc6cf7?q=80&w=1200&auto=format&fit=crop'},
  {id:'ck4', name:'Matcha Mousse Cake', price:140000, cat:'cake', flavor:'matcha', img:'https://images.unsplash.com/photo-1587668178277-a20e35a7f8b0?q=80&w=1200&auto=format&fit=crop'}
];

// ===== Render products
const grid = $("#productGrid");
const searchInput = $("#searchInput");
const filterCategory = $("#filterCategory");
const filterFlavor = $("#filterFlavor");
const sortBy = $("#sortBy");

function renderProducts(){
  const q = (searchInput.value || "").toLowerCase().trim();
  const cat = filterCategory.value;
  const flv = filterFlavor.value;
  const sorted = [...PRODUCTS].sort((a,b)=>{
    switch(sortBy.value){
      case "price-asc": return a.price - b.price;
      case "price-desc": return b.price - a.price;
      case "name-asc": return a.name.localeCompare(b.name);
      case "name-desc": return b.name.localeCompare(a.name);
      default: return (b.popular?1:0)-(a.popular?1:0);
    }
  });
  const filtered = sorted.filter(p=>{
    const okQ = !q || p.name.toLowerCase().includes(q) || p.flavor.includes(q) || p.cat.includes(q);
    const okC = cat==="all" || p.cat===cat;
    const okF = flv==="all" || p.flavor===flv;
    return okQ && okC && okF;
  });

  grid.innerHTML = "";
  for(const p of filtered){
    const card = document.createElement("article");
    card.className = "card product";
    card.innerHTML = `
      <img src="${p.img}" alt="${p.name}">
      <div class="meta">
        <div>
          <div class="name">${p.name}</div>
          <div class="muted">${p.flavor} • ${p.cat}</div>
        </div>
        <div class="price">${fmt(p.price)}</div>
      </div>
      <div class="meta">
        <span class="badge">${p.popular ? "Terpopuler" : "Baru"}</span>
        <button class="btn outline add" data-id="${p.id}">Tambah</button>
      </div>
    `;
    grid.appendChild(card);
  }
}
[searchInput, filterCategory, filterFlavor, sortBy].forEach(el => el.addEventListener("input", renderProducts));
renderProducts();

// ===== Cart logic
const cartDrawer = $("#cartDrawer");
const openCartBtn = $("#openCart");
const closeCartBtn = $("#closeCart");
const cartItems = $("#cartItems");
const cartSubtotal = $("#cartSubtotal");
const cartDiscount = $("#cartDiscount");
const cartTotal = $("#cartTotal");
const cartCount = $("#cartCount");
const checkoutBtn = $("#checkoutBtn");

let CART = JSON.parse(localStorage.getItem("sc-cart") || "[]");

function saveCart(){ localStorage.setItem("sc-cart", JSON.stringify(CART)); }
function addToCart(item){
  const found = CART.find(x => x.id === item.id && JSON.stringify(x.opts||{}) === JSON.stringify(item.opts||{}));
  if(found) found.qty += item.qty || 1;
  else CART.push({...item, qty:item.qty||1});
  updateCart();
}
function removeFromCart(idx){ CART.splice(idx,1); updateCart(); }
function setQty(idx, qty){ CART[idx].qty = Math.max(1, qty|0); updateCart(); }

function calcDiscount(items){
  // Promo: Beli 3 Gratis 1 untuk kategori cookies
  const cookies = items.filter(x => x.cat === "cookies").reduce((a,b)=>a+b.qty,0);
  const free = Math.floor(cookies / 4);
  const cookiePrice = Math.min(...PRODUCTS.filter(p=>p.cat==="cookies").map(p=>p.price));
  return free * cookiePrice;
}

function updateCart(){
  saveCart();
  cartItems.innerHTML = "";
  let subtotal = 0;
  CART.forEach((x, i)=>{
    subtotal += x.price * x.qty;
    const row = document.createElement("div");
    row.className = "card";
    row.innerHTML = `
      <div style="display:flex; gap:10px; align-items:center">
        <img src="${x.img}" alt="${x.name}" style="width:64px;height:64px;object-fit:cover;border-radius:12px">
        <div style="flex:1">
          <div><b>${x.name}</b></div>
          ${x.opts?.text ? `<div class="muted">"${x.opts.text}"</div>` : ""}
          <div class="muted">${fmt(x.price)} × 
            <input type="number" min="1" value="${x.qty}" style="width:64px;background:transparent;border:1px solid #1f2937;border-radius:10px;padding:4px 8px;color:inherit">
          </div>
        </div>
        <button class="btn icon del">🗑</button>
      </div>
    `;
    $("input", row).addEventListener("input", e=> setQty(i, +e.target.value));
    $(".del", row).addEventListener("click", ()=> removeFromCart(i));
    cartItems.appendChild(row);
  });
  const discount = calcDiscount(CART);
  const total = Math.max(0, subtotal - discount);
  cartSubtotal.textContent = fmt(subtotal);
  cartDiscount.textContent = `- ${fmt(discount)}`;
  cartTotal.textContent = fmt(total);
  cartCount.textContent = CART.reduce((a,b)=>a+b.qty,0);
}
updateCart();

grid.addEventListener("click", e=>{
  const btn = e.target.closest(".add");
  if(!btn) return;
  const id = btn.dataset.id;
  const p = PRODUCTS.find(p=>p.id===id);
  addToCart({...p});
  cartDrawer.classList.add("open");
  cartDrawer.setAttribute("aria-hidden", "false");
});

openCartBtn.addEventListener("click", ()=>{
  cartDrawer.classList.add("open");
  cartDrawer.setAttribute("aria-hidden", "false");
});
closeCartBtn.addEventListener("click", ()=>{
  cartDrawer.classList.remove("open");
  cartDrawer.setAttribute("aria-hidden", "true");
});

// ===== Checkout
const checkoutModal = $("#checkoutModal");
const closeCheckout = $("#closeCheckout");
const cancelCheckout = $("#cancelCheckout");
const submitOrder = $("#submitOrder");
const checkoutSummary = $("#checkoutSummary");
const checkoutForm = $("#checkoutForm");

checkoutBtn.addEventListener("click", ()=>{
  if(CART.length===0){ alert("Keranjang masih kosong"); return; }
  renderSummary();
  checkoutModal.showModal();
});
[closeCheckout, cancelCheckout].forEach(b=> b.addEventListener("click", ()=> checkoutModal.close()));

function renderSummary(){
  checkoutSummary.innerHTML = CART.map(x=>`<div style="display:flex;justify-content:space-between"><span>${x.name} × ${x.qty}</span><b>${fmt(x.price * x.qty)}</b></div>`).join("");
  const disc = calcDiscount(CART);
  const sub = CART.reduce((a,b)=>a+b.price*b.qty,0);
  const tot = Math.max(0, sub-disc);
  checkoutSummary.insertAdjacentHTML("beforeend", `<hr><div style="display:flex;justify-content:space-between"><span>Subtotal</span><b>${fmt(sub)}</b></div>`);
  checkoutSummary.insertAdjacentHTML("beforeend", `<div style="display:flex;justify-content:space-between"><span>Diskon</span><b>- ${fmt(disc)}</b></div>`);
  checkoutSummary.insertAdjacentHTML("beforeend", `<div style="display:flex;justify-content:space-between;font-size:18px"><span>Total</span><b>${fmt(tot)}</b></div>`);
}

checkoutForm.addEventListener("change", e=>{
  const method = checkoutForm.method.value;
  $("#addressField").style.display = method === "pickup" ? "none" : "block";
});

submitOrder.addEventListener("click", (e)=>{
  e.preventDefault();
  const fd = new FormData(checkoutForm);
  const data = Object.fromEntries(fd.entries());
  // simple coupon demo
  let couponDisc = 0;
  if((data.coupon||"").toUpperCase() === "YUMMY20"){
    const sub = CART.reduce((a,b)=>a+b.price*b.qty,0);
    couponDisc = Math.round(sub * .2);
  }
  const promoDisc = calcDiscount(CART);
  const sub = CART.reduce((a,b)=>a+b.price*b.qty,0);
  const tot = Math.max(0, sub - promoDisc - couponDisc);

  const orderNo = "SC" + Date.now().toString().slice(-8);
  const order = {orderNo, at: new Date().toISOString(), items: CART, data, sub, promoDisc, couponDisc, tot};
  localStorage.setItem("sc-last-order", JSON.stringify(order));
  alert(`Pesanan ${orderNo} berhasil dibuat! Total: ${fmt(tot)}. Kami kirimkan konfirmasi ke ${data.email}.`);
  CART = []; updateCart();
  checkoutModal.close();
  // Offer print
  const receipt = window.open("", "_blank");
  receipt.document.write(`<title>Receipt ${orderNo}</title><pre>${JSON.stringify(order,null,2)}</pre>`);
  receipt.document.close();
});

// ===== Builder (custom cake)
const builderModal = $("#builderModal");
$("#openBuild").addEventListener("click", ()=>{
  builderModal.showModal();
  updateBuilder();
});
$("#closeBuild").addEventListener("click", ()=> builderModal.close());
const bSize = $("#b-size"), bFlavor = $("#b-flavor"), bTopping = $("#b-topping"), bText = $("#b-text");
[bSize, bFlavor, bTopping, bText].forEach(el=> el.addEventListener("input", updateBuilder));

function updateBuilder(){
  const size = +bSize.value;
  const base = 90000 + (size-16)*5000;
  const flavorFee = {vanilla:0, chocolate:5000, strawberry:7000, matcha:9000}[bFlavor.value] || 0;
  const tops = Array.from(bTopping.selectedOptions).map(o=>o.value);
  const topFee = tops.length * 4000;
  const price = base + flavorFee + topFee;
  $("#builderPrice").textContent = fmt(price);

  const canvas = $("#cakeCanvas");
  canvas.style.background = `radial-gradient(circle at 50% 30%, rgba(255,255,255,.6), transparent 60%), conic-gradient(from 0deg, var(--brand), var(--accent))`;
  canvas.setAttribute("data-text", (bText.value||""));
  canvas.innerHTML = "";
  // Sprinkle toppings
  for(let i=0;i<tops.length*8;i++){
    const dot = document.createElement("span");
    dot.className = "topping";
    dot.style.left = Math.random()*200 + "px";
    dot.style.top  = Math.random()*200 + "px";
    dot.style.background = ["berries","almond","oreo","sprinkles"].includes(tops[0]) ? "white" : "gold";
    canvas.appendChild(dot);
  }
}

$("#addBuildToCart").addEventListener("click", ()=>{
  const size = +bSize.value;
  const tops = Array.from(bTopping.selectedOptions).map(o=>o.value);
  const priceText = $("#builderPrice").textContent;
  const price = Number(priceText.replace(/[^\d]/g,""));
  const item = {
    id: "custom-"+Date.now(),
    name: `Custom Cake ${size}cm (${bFlavor.value})`,
    price,
    img: "https://images.unsplash.com/photo-1616594039964-ae9021a4009b?q=80&w=1200&auto=format&fit=crop",
    cat: "cake",
    opts: {size, flavor: bFlavor.value, topping: tops, text: bText.value}
  };
  addToCart(item);
  builderModal.close();
});

// ===== Pickup modal
const pickupModal = $("#pickupModal");
$("#openPickup").addEventListener("click", ()=> pickupModal.showModal());
$("#closePickup").addEventListener("click", ()=> pickupModal.close());
$("#savePickup").addEventListener("click", ()=>{
  const date = $("#p-date").value, time = $("#p-time").value;
  if(!date || !time) return alert("Lengkapi tanggal & jam ya!");
  localStorage.setItem("sc-pickup", JSON.stringify({date, time}));
  alert("Jadwal pickup disimpan!");
  pickupModal.close();
});

// ===== Add-to-cart from slider (easter egg)
track.addEventListener("dblclick", ()=>{
  // add best-seller
  const p = PRODUCTS.find(x=>x.popular);
  addToCart(p);
  cartDrawer.classList.add("open");
});
